import io, os, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app import create_app
from app.models import db, Driver, Payment

tmp = tempfile.mkdtemp()
app = create_app("sqlite:///" + os.path.join(tmp, "t.db"))
c = app.test_client()
S = os.path.join(os.path.dirname(__file__), "..", "sample_data")

def up(kind, fn, **extra):
    with open(os.path.join(S, fn), "rb") as fh:
        return c.post("/import", data={"kind": kind, "file": (io.BytesIO(fh.read()), fn), **extra},
                      content_type="multipart/form-data")

r = up("callbook", "callbook_sample.xlsx"); assert r.status_code == 200, r.status_code
r = up("statement", "statement_sample.xls", fee="450"); assert r.status_code == 200
r = up("statement", "statement_sample.xls", fee="450")  # دوباره: همه باید تکراری باشند
with app.app_context():
    n = Payment.query.count(); tot = sum(p.amount for p in Payment.query)
    print("payments", n, "total", tot, "drivers", Driver.query.count())
    assert n == 61 and tot == 7982864450 - 61 * 450
    d = Driver.query.filter(Driver.name_norm.contains("چنگیزی")).first()
    assert d and d.trucks, "matching failed"; did = d.id
    print("chang:", d.name, [t.plate for t in d.trucks], sum(p.amount for p in d.payments) if hasattr(d, 'payments') else "")
r = c.post("/receipts/form", data={"driver_id": did, "date": "۱۴۰۵/۰۶/۰۱", "amount": "100,000,000", "notes": "رسید تست"})
assert r.status_code == 302
for url in ["/", "/?q=چنگیزی", "/?date_from=1405/06/01&date_to=1405/06/31", "/?plate=322", "/?status=debtor", "/balances.xlsx",
            "/drivers", f"/drivers/{did}", "/payments", "/payments?q=چنگیزی&account=418679617&text=ادبلو",
            "/payments.xlsx", "/receipts", "/trucks", "/accounts", "/import", "/payments/form", "/receipts/form?id=1"]:
    r = c.get(url); assert r.status_code == 200, (url, r.status_code)
html = c.get(f"/drivers/{did}").get_data(as_text=True)
assert "رسید تست" in html and "100,000,000" in html
r = c.post(f"/payments/1/note", data={"notes": "توضیح"}); assert r.status_code == 302
r = c.post("/payments/form", data={"date": "1405/06/10", "amount": "5000000", "driver_id": did, "notes": "دستی"}); assert r.status_code == 302
print("ALL OK")
