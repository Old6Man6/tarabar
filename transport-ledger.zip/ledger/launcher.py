"""نقطه‌ی ورود نسخه‌ی exe: سرور را بالا می‌آورد و مرورگر را باز می‌کند."""
import os
import socket
import sys
import threading
import time
import webbrowser

from app import create_app

PORT_START = 8000


def port_free(port):
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def main():
    lan = "--lan" in sys.argv  # برای دسترسی از سایر کامپیوترهای شبکه
    port = PORT_START
    if not port_free(port):
        # احتمالاً برنامه از قبل باز است؛ فقط مرورگر را باز کن
        webbrowser.open(f"http://localhost:{port}")
        return
    app = create_app()
    url = f"http://localhost:{port}"
    print("=" * 52)
    print(" Driver Ledger is running:", url)
    print(" Keep this window open. Close it to stop the program.")
    print(" Data file: data\\ledger.db  (use the Backup link to save a copy)")
    print("=" * 52)
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    from waitress import serve
    serve(app, host="0.0.0.0" if lan else "127.0.0.1", port=port, threads=4)


if __name__ == "__main__":
    main()
