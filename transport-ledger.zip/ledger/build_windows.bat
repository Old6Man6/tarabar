@echo off
rem اجرا روی یک کامپیوتر ویندوز که Python 3.11+ نصب دارد  ->  خروجی: dist\DriverLedger.exe
python -m venv .venv || goto :err
call .venv\Scripts\activate.bat
pip install -r requirements.txt pyinstaller || goto :err
pyinstaller --noconfirm --clean --onefile --name DriverLedger ^
  --add-data "app\templates;app\templates" --add-data "app\static;app\static" ^
  --hidden-import xlrd --hidden-import openpyxl --hidden-import waitress ^
  --exclude-module psycopg2 --exclude-module tkinter --exclude-module matplotlib --exclude-module scipy ^
  launcher.py || goto :err
echo.
echo Done: dist\DriverLedger.exe
exit /b 0
:err
echo BUILD FAILED
exit /b 1
