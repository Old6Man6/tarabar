import os
import sys
from flask import Flask, request, Response
from .models import db
from .utils import money


def create_app(db_url=None):
    app = Flask(__name__)
    if getattr(sys, "frozen", False):  # نسخه‌ی exe: داده‌ها کنار فایل اجرایی
        base = os.path.join(os.path.dirname(sys.executable), "data")
    else:
        base = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))
    os.makedirs(base, exist_ok=True)
    url = db_url or os.environ.get("DATABASE_URL") or "sqlite:///" + os.path.join(base, "ledger.db")
    if url.startswith("postgres://"):
        url = url.replace("postgres://", "postgresql+psycopg2://", 1)
    app.config.update(SQLALCHEMY_DATABASE_URI=url,
                      SECRET_KEY=os.environ.get("SECRET_KEY", "dev-secret"),
                      MAX_CONTENT_LENGTH=20 * 1024 * 1024)
    db.init_app(app)
    app.jinja_env.filters["money"] = money

    from .views import bp
    app.register_blueprint(bp)

    password = os.environ.get("APP_PASSWORD")
    if password:
        @app.before_request
        def _auth():
            a = request.authorization
            if not a or a.password != password:
                return Response("ورود لازم است", 401, {"WWW-Authenticate": 'Basic realm="ledger"'})

    with app.app_context():
        db.create_all()
    return app
