import re
import pandas as pd
from .models import db, Driver, Truck, Account, Payment, ImportBatch
from .utils import fix, norm, parse_jdate, clean_holder


def _read(file_storage, **kw):
    name = (file_storage.filename or "").lower()
    engine = "xlrd" if name.endswith(".xls") else "openpyxl"
    return pd.read_excel(file_storage, engine=engine, header=None, **kw)


def _tokens(name):
    return fix(name).replace("\u200c", " ").split()


def find_driver(name, cache):
    """پیدا کردن راننده با نام: مطابقت دقیق ← شمول ← نام خانوادگی (برای کالبوک‌هایی که فقط فامیل نوشته‌اند)."""
    n = norm(name)
    if not n:
        return None
    for d in cache:
        if d.name_norm == n:
            return d
    cands = [d for d in cache if len(d.name_norm or "") >= 6 and len(n) >= 6
             and (d.name_norm in n or n in d.name_norm)]
    if cands:
        cands.sort(key=lambda d: -len(d.name_norm))
        if len(cands) == 1 or len(cands[0].name_norm) > len(cands[1].name_norm):
            return cands[0]
        return None
    toks = _tokens(name)
    last = norm(toks[-1])
    firsts = {norm(t) for t in toks[:-1]}
    hits = []
    for d in cache:
        dt = _tokens(d.name)
        if not dt:
            continue
        dl, dfirst = norm(dt[-1]), {norm(t) for t in dt[:-1]}
        if not (dl == last or (len(last) <= 2 and dl.startswith(last))):
            continue
        if len(toks) == 1 or len(dt) == 1 or (firsts & dfirst):
            hits.append(d)
    return hits[0] if len(hits) == 1 else None


def new_driver(name, review=False):
    d = Driver(name=fix(name), name_norm=norm(name), needs_review=review)
    db.session.add(d)
    return d


# ---------------------------------------------------------------- پرینت حساب
HEADERS = {"یادداشت": "memo", "توضیحات": "desc", "شماره سند": "doc",
           "برداشت": "amount", "تاریخ": "date", "ردیف": "row"}


def import_statement(file_storage, fee=450):
    raw = _read(file_storage)
    hdr = None
    for i in range(min(len(raw), 15)):
        cells = [fix(c) for c in raw.iloc[i].tolist()]
        if "برداشت" in cells and "تاریخ" in cells:
            hdr = i
            break
    if hdr is None:
        raise ValueError("ستون‌های «برداشت» و «تاریخ» در فایل پیدا نشد. فایل پرینت حساب درست است؟")
    cols = {}
    for j, c in enumerate(raw.iloc[hdr].tolist()):
        key = HEADERS.get(fix(c))
        if key and key not in cols:
            cols[key] = j

    batch = ImportBatch(filename=file_storage.filename, kind="statement")
    db.session.add(batch)
    db.session.flush()

    drivers = Driver.query.all()
    accounts = {a.number: a for a in Account.query.all()}
    existing = {(p.doc_number, p.date_key, p.gross, p.account_number)
                for p in Payment.query.with_entities(Payment.doc_number, Payment.date_key, Payment.gross,
                                                     Payment.account_number).all()}
    res = {"added": 0, "dups": 0, "bad": [], "new_drivers": [], "new_accounts": 0, "no_fee": 0, "total": 0}

    def cell(row, key):
        return row[cols[key]] if key in cols else None

    for i in range(hdr + 1, len(raw)):
        row = raw.iloc[i].tolist()
        dt = parse_jdate(cell(row, "date"))
        gross = pd.to_numeric(cell(row, "amount"), errors="coerce")
        if dt is None or pd.isna(gross) or gross <= 0:
            continue  # ردیف جمع/خالی
        gross = int(gross)
        desc = fix(cell(row, "desc"))
        m = re.search(r"حساب\s*(\d+)\s*(.*)$", desc)
        if not m:
            res["bad"].append(f"ردیف {i + 1}: شماره حساب در توضیحات پیدا نشد")
            continue
        acc_no = m.group(1).lstrip("0")
        holder = clean_holder(m.group(2))
        doc = fix(cell(row, "doc")) or None
        key = (doc, dt[1], gross, acc_no)
        if key in existing:
            res["dups"] += 1
            continue
        existing.add(key)

        acc = accounts.get(acc_no)
        if acc is None:
            drv = find_driver(holder, drivers)
            if drv is None:
                drv = new_driver(holder, review=True)
                db.session.flush()
                drivers.append(drv)
                res["new_drivers"].append(drv.name)
            if drv.name_norm != norm(holder) and drv.name_norm in norm(holder):
                drv.name, drv.name_norm = holder, norm(holder)  # نام کامل‌تر از بانک
            acc = Account(number=acc_no, holder_name=holder, driver_id=drv.id)
            db.session.add(acc)
            db.session.flush()
            accounts[acc_no] = acc
            res["new_accounts"] += 1
        drv = acc.driver if acc.driver else db.session.get(Driver, acc.driver_id)

        net = gross - fee if fee and gross > fee and (gross - fee) % 1000 == 0 else gross
        if net == gross and fee:
            res["no_fee"] += 1
        truck_id = drv.trucks[0].id if len(drv.trucks) == 1 else None
        db.session.add(Payment(
            date_j=dt[0], date_key=dt[1], amount=net, fee=gross - net, gross=gross,
            driver_id=drv.id, truck_id=truck_id, account_id=acc.id, account_number=acc_no,
            doc_number=doc, row_no=fix(cell(row, "row")).replace(".0", "") or None,
            bank_memo=fix(cell(row, "memo")), bank_desc=desc, batch_id=batch.id))
        res["added"] += 1
        res["total"] += net
    batch.added, batch.skipped = res["added"], res["dups"]
    db.session.commit()
    res["batch_id"] = batch.id
    return res


# ---------------------------------------------------------------- کالبوک ناوگان
def import_callbook(file_storage, sheet=None):
    sheets = _read(file_storage, sheet_name=None)
    valid = {}
    for name, df in sheets.items():
        for i in range(min(len(df), 10)):
            cells = [fix(c) for c in df.iloc[i].tolist()]
            if any("شرح کامیون" in c for c in cells) and any("شماره پلاک" in c for c in cells):
                valid[name] = (df, i, cells)
                break
    if not valid:
        raise ValueError("هیچ شیتی با ستون‌های «شرح کامیون» و «شماره پلاک» پیدا نشد.")
    if sheet and sheet in valid:
        chosen = sheet
    else:
        monthly = [n for n in valid if "لجستیک" in n and "پیش" not in n]
        chosen = (monthly or list(valid))[-1]  # آخرین شیت ماهانه = جدیدترین ماه
    df, hdr, cells = valid[chosen]

    def col(label):
        for j, c in enumerate(cells):
            if label in c:
                return j
        return None
    c_r = next((j for j, c in enumerate(cells) if c.strip().upper() == "R"), 0)
    c_kind, c_year, c_plate, c_serial, c_driver, c_status = (
        col("شرح کامیون"), col("سال ساخت"), col("شماره پلاک"), col("سریال پلاک"), col("راننده"), col("وضعیت"))

    drivers = Driver.query.all()
    res = {"sheet": chosen, "trucks_new": 0, "trucks_upd": 0, "drivers_new": [], "links": 0}
    for i in range(hdr + 1, len(df)):
        row = df.iloc[i].tolist()
        r = row[c_r]
        if pd.isna(r) or not str(r).strip().replace(".0", "").isdigit():
            continue  # ردیف نیم‌یدک و ... (بدون ردیف) رد می‌شود
        plate = fix(row[c_plate]) if not pd.isna(row[c_plate]) else ""
        if not plate:
            continue
        t = Truck.query.filter_by(plate_norm=norm(plate)).first()
        def g(j):
            return "" if j is None or pd.isna(row[j]) else fix(row[j])
        fields = dict(kind=g(c_kind), year=g(c_year).replace(".0", ""), serial=g(c_serial), status=g(c_status))
        if t:
            for k, v in fields.items():
                setattr(t, k, v)
            res["trucks_upd"] += 1
        else:
            t = Truck(plate=plate, plate_norm=norm(plate), **fields)
            db.session.add(t)
            db.session.flush()
            res["trucks_new"] += 1
        parts = [n.strip() for n in re.split(r"\s{2,}|\s*[،,/]\s*|\s+و\s+", fix_keep(row[c_driver])) if n.strip()]
        names = parts[:1] + [re.sub(r"^و(?=\S)", "", n) for n in parts[1:]]  # «اسدی  وعنایتی»
        for n in names:
            d = find_driver(n, drivers)
            if d is None:
                d = new_driver(n)
                db.session.flush()
                drivers.append(d)
                res["drivers_new"].append(d.name)
            elif d.needs_review and len(norm(n)) >= len(d.name_norm):
                d.name, d.name_norm = fix(n), norm(n)  # نام کامل‌تر از کالبوک
            if t not in d.trucks:
                d.trucks.append(t)
                res["links"] += 1
    db.session.commit()
    res["sheets"] = list(valid)
    return res


def fix_keep(v):
    """مثل fix ولی فاصله‌های دوتایی (جداکننده‌ی دو راننده) حفظ می‌شود."""
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return ""
    s = fix_raw(str(v))
    return s.strip()


def fix_raw(s):
    from .utils import _DIGITS, _CHARS, _INVISIBLE
    return _INVISIBLE.sub("", s.translate(_DIGITS).translate(_CHARS))
