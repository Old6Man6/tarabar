import re
import jdatetime

_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_CHARS = str.maketrans({"ي": "ی", "ك": "ک", "ة": "ه", "ۀ": "ه", "ئ": "ی", "ـ": ""})
_INVISIBLE = re.compile("[\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff]")


def fix(s):
    """پاکسازی متن: ارقام فارسی→لاتین، ی/ک عربی→فارسی، حذف کاراکترهای جهت‌دهی."""
    if s is None:
        return ""
    s = str(s).translate(_DIGITS).translate(_CHARS)
    s = _INVISIBLE.sub("", s)
    return re.sub(r"[ \t]+", " ", s).strip()


def norm(s):
    """شکل نرمال برای جست‌وجو و مقایسه: بدون فاصله/نیم‌فاصله."""
    return re.sub(r"[\s\u200c]+", "", fix(s)).lower()


def parse_jdate(s):
    """'1405/05/19' → ('1405/05/19', 14050519) یا None."""
    m = re.match(r"^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$", fix(s))
    if not m:
        return None
    y, mo, d = map(int, m.groups())
    if not (1300 <= y <= 1500 and 1 <= mo <= 12 and 1 <= d <= (31 if mo <= 6 else 30)):
        return None
    return f"{y:04d}/{mo:02d}/{d:02d}", y * 10000 + mo * 100 + d


def parse_money(s):
    s = fix(s).replace(",", "").replace("٬", "").replace(" ", "")
    if not s:
        return None
    try:
        return int(float(s))
    except ValueError:
        return None


def money(n):
    try:
        return f"{int(n or 0):,}"
    except (TypeError, ValueError):
        return "0"


def today_j():
    return jdatetime.date.today().strftime("%Y/%m/%d")


def clean_holder(name):
    """نام گیرنده در پرینت بانک ناقص و با «وکارمزد» بریده شده؛ تمیزش می‌کنیم."""
    n = fix(name)
    n = re.sub(r"\s+و\s*(ک|کا|کار|کارم|کارمز|کارمزد)?$", "", n)
    n = re.sub(r"و(ک|کا|کار|کارم|کارمز|کارمزد)$", "", n)
    n = re.sub(r"(?<=\S)راو$", "", n)
    return n.strip()
