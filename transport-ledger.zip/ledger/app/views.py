import io
from flask import (Blueprint, render_template, request, redirect, url_for, flash, send_file, abort)
from sqlalchemy import func, or_, select
from openpyxl import Workbook
from .models import db, Driver, Truck, Account, Payment, Receipt, ImportBatch
from .utils import fix, norm, parse_jdate, parse_money, today_j
from .importers import import_statement, import_callbook, new_driver

bp = Blueprint("main", __name__)
PER_PAGE = 100


# ------------------------------------------------------------------ کمکی‌ها
def status_of(b):
    if b > 0:
        return "debtor", "بدهکار"
    if b < 0:
        return "creditor", "طلبکار"
    return "even", "صاف"


def parse_filters(args):
    f = {k: fix(args.get(k, "")) for k in ("q", "date_from", "date_to", "plate", "account", "text", "status")}
    f["driver_id"] = args.get("driver_id", type=int)
    df, dt = parse_jdate(f["date_from"]), parse_jdate(f["date_to"])
    f["kf"], f["kt"] = (df[1] if df else None), (dt[1] if dt else None)
    f["bad_date"] = bool((f["date_from"] and not df) or (f["date_to"] and not dt))
    return f


def apply_filters(query, model, f, with_text=False):
    if f["driver_id"]:
        query = query.filter(model.driver_id == f["driver_id"])
    if f["q"]:
        query = query.filter(model.driver_id.in_(select(Driver.id).where(Driver.name_norm.contains(norm(f["q"])))))
    if f["kf"]:
        query = query.filter(model.date_key >= f["kf"])
    if f["kt"]:
        query = query.filter(model.date_key <= f["kt"])
    if f["plate"]:
        query = query.filter(model.truck_id.in_(select(Truck.id).where(Truck.plate_norm.contains(norm(f["plate"])))))
    if with_text:
        if f["account"] and hasattr(model, "account_number"):
            query = query.filter(model.account_number.contains(f["account"].lstrip("0")))
        if f["text"]:
            t = f["text"]
            conds = [model.notes.contains(t)]
            if hasattr(model, "bank_memo"):
                conds += [model.bank_memo.contains(t)]
            if hasattr(model, "receipt_no"):
                conds += [model.receipt_no.contains(t)]
            query = query.filter(or_(*conds))
    return query


def balance_rows(f):
    dq = Driver.query
    if f["q"]:
        dq = dq.filter(Driver.name_norm.contains(norm(f["q"])))
    if f["driver_id"]:
        dq = dq.filter(Driver.id == f["driver_id"])
    drivers = dq.order_by(Driver.name).all()

    def agg(model):
        q = db.session.query(model.driver_id, func.coalesce(func.sum(model.amount), 0), func.count(model.id))
        q = apply_filters(q, model, {**f, "q": "", "driver_id": None})
        return {d: (int(s), c) for d, s, c in q.group_by(model.driver_id).all()}
    paid, rcv = agg(Payment), agg(Receipt)

    narrowed = bool(f["kf"] or f["kt"] or f["plate"])
    plate_ids = set()
    if f["plate"]:
        for t in Truck.query.filter(Truck.plate_norm.contains(norm(f["plate"]))).all():
            plate_ids |= {d.id for d in t.drivers}
    rows = []
    for d in drivers:
        p, pc = paid.get(d.id, (0, 0))
        r, rc = rcv.get(d.id, (0, 0))
        if narrowed and not (pc or rc or d.id in plate_ids):
            continue
        if not d.active and not (pc or rc):
            continue
        opening = 0 if (f["kf"] or f["plate"]) else (d.opening_balance or 0)
        bal = opening + p - r
        code, label = status_of(bal)
        if f["status"] and f["status"] != code:
            continue
        rows.append(dict(driver=d, paid=p, paid_n=pc, receipts=r, receipts_n=rc, opening=opening,
                         balance=bal, code=code, label=label))
    return rows


def xlsx_response(name, headers, data):
    wb = Workbook()
    ws = wb.active
    ws.sheet_view.rightToLeft = True
    ws.append(headers)
    for r in data:
        ws.append(r)
    for i, h in enumerate(headers, 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = max(14, len(h) + 4)
    bio = io.BytesIO()
    wb.save(bio)
    bio.seek(0)
    return send_file(bio, as_attachment=True, download_name=name,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def date_or_flash(s):
    d = parse_jdate(s)
    if not d:
        flash("تاریخ نامعتبر است. قالب درست: 1405/05/19", "err")
    return d


def back(default="main.dashboard", **kw):
    nxt = request.form.get("next") or request.args.get("next")
    return redirect(nxt if nxt and nxt.startswith("/") else url_for(default, **kw))


@bp.app_context_processor
def inject():
    def page_url(n):
        return url_for(request.endpoint, **{**(request.view_args or {}), **request.args.to_dict(), "page": n})
    return dict(all_drivers=Driver.query.order_by(Driver.name).all(),
                all_trucks=Truck.query.order_by(Truck.plate).all(),
                today=today_j(), page_url=page_url, status_of=status_of, cur=request.full_path.rstrip("?"))


# ------------------------------------------------------------------ داشبورد
@bp.route("/")
def dashboard():
    f = parse_filters(request.args)
    rows = balance_rows(f)
    tot = dict(paid=sum(r["paid"] for r in rows), receipts=sum(r["receipts"] for r in rows),
               balance=sum(r["balance"] for r in rows))
    review = Driver.query.filter_by(needs_review=True).count()
    return render_template("dashboard.html", f=f, rows=rows, tot=tot, review=review)


@bp.route("/balances.xlsx")
def balances_xlsx():
    f = parse_filters(request.args)
    data = [[r["driver"].name, r["opening"], r["paid"], r["receipts"], r["balance"], r["label"]] for r in balance_rows(f)]
    return xlsx_response("balances.xlsx", ["راننده", "مانده قبلی", "جمع واریزی", "جمع رسیدها", "مانده", "وضعیت"], data)


# ------------------------------------------------------------------ رانندگان
@bp.route("/drivers")
def drivers():
    q = fix(request.args.get("q", ""))
    dq = Driver.query
    if q:
        dq = dq.filter(Driver.name_norm.contains(norm(q)))
    return render_template("drivers.html", items=dq.order_by(Driver.name).all(), q=q)


@bp.route("/drivers/new", methods=["POST"])
def driver_new():
    name = fix(request.form.get("name"))
    if not name:
        flash("نام راننده لازم است.", "err")
        return redirect(url_for("main.drivers"))
    d = new_driver(name)
    d.phone = fix(request.form.get("phone"))
    d.notes = request.form.get("notes", "").strip()
    db.session.commit()
    flash("راننده اضافه شد.", "ok")
    return redirect(url_for("main.driver_detail", id=d.id))


@bp.route("/drivers/<int:id>")
def driver_detail(id):
    d = db.get_or_404(Driver, id)
    f = parse_filters(request.args)
    f.update(driver_id=id, q="", plate="")
    pays = apply_filters(Payment.query, Payment, f).order_by(Payment.date_key.desc(), Payment.id.desc()).all()
    rcps = apply_filters(Receipt.query, Receipt, f).order_by(Receipt.date_key.desc(), Receipt.id.desc()).all()
    paid, rcv = sum(p.amount for p in pays), sum(r.amount for r in rcps)
    opening = 0 if f["kf"] else (d.opening_balance or 0)
    bal = opening + paid - rcv
    code, label = status_of(bal)
    return render_template("driver.html", d=d, f=f, pays=pays, rcps=rcps, paid=paid, rcv=rcv,
                           opening=opening, bal=bal, code=code, label=label)


@bp.route("/drivers/<int:id>/edit", methods=["POST"])
def driver_edit(id):
    d = db.get_or_404(Driver, id)
    name = fix(request.form.get("name"))
    if name:
        d.name, d.name_norm = name, norm(name)
    d.phone = fix(request.form.get("phone"))
    d.notes = request.form.get("notes", "").strip()
    ob = parse_money(request.form.get("opening_balance"))
    d.opening_balance = ob or 0
    d.active = bool(request.form.get("active"))
    d.needs_review = False
    db.session.commit()
    flash("ذخیره شد.", "ok")
    return redirect(url_for("main.driver_detail", id=id))


@bp.route("/drivers/<int:id>/delete", methods=["POST"])
def driver_delete(id):
    d = db.get_or_404(Driver, id)
    if Payment.query.filter_by(driver_id=id).count() or Receipt.query.filter_by(driver_id=id).count() or d.accounts:
        flash("این راننده واریزی/رسید/حساب دارد؛ حذف نمی‌شود. می‌توانید غیرفعالش کنید یا با راننده‌ی دیگر ادغام کنید.", "err")
        return redirect(url_for("main.driver_detail", id=id))
    d.trucks.clear()
    db.session.delete(d)
    db.session.commit()
    flash("راننده حذف شد.", "ok")
    return redirect(url_for("main.drivers"))


@bp.route("/drivers/<int:id>/merge", methods=["POST"])
def driver_merge(id):
    src = db.get_or_404(Driver, id)
    dst = db.get_or_404(Driver, request.form.get("target", type=int) or 0)
    if src.id == dst.id:
        flash("مقصد باید راننده‌ی دیگری باشد.", "err")
        return redirect(url_for("main.driver_detail", id=id))
    for model in (Payment, Receipt, Account):
        model.query.filter_by(driver_id=src.id).update({"driver_id": dst.id})
    for t in list(src.trucks):
        if t not in dst.trucks:
            dst.trucks.append(t)
    dst.opening_balance = (dst.opening_balance or 0) + (src.opening_balance or 0)
    src.trucks.clear()
    db.session.flush()
    db.session.delete(src)
    db.session.commit()
    flash(f"«{src.name}» در «{dst.name}» ادغام شد.", "ok")
    return redirect(url_for("main.driver_detail", id=dst.id))


@bp.route("/drivers/<int:id>/accounts", methods=["POST"])
def account_add(id):
    d = db.get_or_404(Driver, id)
    no = fix(request.form.get("number")).lstrip("0")
    if not no.isdigit():
        flash("شماره حساب باید عدد باشد.", "err")
    elif Account.query.filter_by(number=no).first():
        flash("این شماره حساب قبلاً ثبت شده (در حساب‌ها جست‌وجو کنید).", "err")
    else:
        db.session.add(Account(number=no, holder_name=fix(request.form.get("holder_name")) or d.name,
                               notes=request.form.get("notes", "").strip(), driver_id=id))
        db.session.commit()
        flash("حساب اضافه شد.", "ok")
    return redirect(url_for("main.driver_detail", id=id))


@bp.route("/drivers/<int:id>/trucks", methods=["POST"])
def driver_truck(id):
    d = db.get_or_404(Driver, id)
    t = db.session.get(Truck, request.form.get("truck_id", type=int) or 0)
    if request.form.get("action") == "remove" and t in d.trucks:
        d.trucks.remove(t)
    elif t and t not in d.trucks:
        d.trucks.append(t)
    db.session.commit()
    return back("main.driver_detail", id=id)


# ------------------------------------------------------------------ حساب‌ها
@bp.route("/accounts")
def accounts():
    q = fix(request.args.get("q", ""))
    aq = Account.query.join(Driver)
    if q:
        aq = aq.filter(or_(Driver.name_norm.contains(norm(q)), Account.number.contains(q.lstrip("0")),
                           Account.holder_name.contains(q)))
    counts = dict(db.session.query(Payment.account_id, func.count(Payment.id)).group_by(Payment.account_id).all())
    return render_template("accounts.html", items=aq.order_by(Driver.name).all(), q=q, counts=counts)


@bp.route("/accounts/<int:id>/edit", methods=["POST"])
def account_edit(id):
    a = db.get_or_404(Account, id)
    new_driver_id = request.form.get("driver_id", type=int)
    a.holder_name = fix(request.form.get("holder_name"))
    a.notes = request.form.get("notes", "").strip()
    if new_driver_id and new_driver_id != a.driver_id:
        if request.form.get("move_payments"):
            Payment.query.filter_by(account_id=a.id).update({"driver_id": new_driver_id})
        a.driver_id = new_driver_id
    db.session.commit()
    flash("حساب ذخیره شد.", "ok")
    return back("main.accounts")


@bp.route("/accounts/<int:id>/delete", methods=["POST"])
def account_delete(id):
    a = db.get_or_404(Account, id)
    if Payment.query.filter_by(account_id=id).count():
        flash("این حساب واریزی دارد و حذف نمی‌شود.", "err")
    else:
        db.session.delete(a)
        db.session.commit()
        flash("حساب حذف شد.", "ok")
    return back("main.accounts")


# ------------------------------------------------------------------ کامیون‌ها
@bp.route("/trucks")
def trucks():
    q = fix(request.args.get("q", ""))
    tq = Truck.query
    if q:
        tq = tq.filter(or_(Truck.plate_norm.contains(norm(q)), Truck.kind.contains(q)))
    return render_template("trucks.html", items=tq.order_by(Truck.plate).all(), q=q)


@bp.route("/trucks/save", methods=["POST"])
def truck_save():
    plate = fix(request.form.get("plate"))
    if not plate:
        flash("شماره پلاک لازم است.", "err")
        return redirect(url_for("main.trucks"))
    t = db.session.get(Truck, request.form.get("id", type=int) or 0)
    dup = Truck.query.filter_by(plate_norm=norm(plate)).first()
    if dup and (not t or dup.id != t.id):
        flash("این پلاک قبلاً ثبت شده.", "err")
        return redirect(url_for("main.trucks"))
    if not t:
        t = Truck()
        db.session.add(t)
    t.plate, t.plate_norm = plate, norm(plate)
    t.serial, t.kind = fix(request.form.get("serial")), fix(request.form.get("kind"))
    t.year, t.status = fix(request.form.get("year")), fix(request.form.get("status"))
    t.notes = request.form.get("notes", "").strip()
    db.session.commit()
    flash("کامیون ذخیره شد.", "ok")
    return redirect(url_for("main.trucks"))


@bp.route("/trucks/<int:id>/delete", methods=["POST"])
def truck_delete(id):
    t = db.get_or_404(Truck, id)
    if Payment.query.filter_by(truck_id=id).count() or Receipt.query.filter_by(truck_id=id).count():
        flash("این کامیون در واریزی/رسید استفاده شده و حذف نمی‌شود.", "err")
    else:
        t.drivers.clear()
        db.session.delete(t)
        db.session.commit()
        flash("حذف شد.", "ok")
    return redirect(url_for("main.trucks"))


# ------------------------------------------------------------------ واریزی‌ها
@bp.route("/payments")
def payments():
    f = parse_filters(request.args)
    q = apply_filters(Payment.query, Payment, f, with_text=True)
    total = q.with_entities(func.coalesce(func.sum(Payment.amount), 0)).scalar()
    page = q.order_by(Payment.date_key.desc(), Payment.id.desc()).paginate(
        page=request.args.get("page", 1, type=int), per_page=PER_PAGE, error_out=False)
    return render_template("payments.html", f=f, page=page, total=int(total))


@bp.route("/payments.xlsx")
def payments_xlsx():
    f = parse_filters(request.args)
    items = apply_filters(Payment.query, Payment, f, with_text=True).order_by(Payment.date_key, Payment.id).all()
    data = [[p.date_j, p.driver.name, p.truck.plate if p.truck else "", p.account_number, p.amount, p.fee,
             p.doc_number or "", p.bank_memo, p.notes] for p in items]
    return xlsx_response("payments.xlsx", ["تاریخ", "راننده", "پلاک", "شماره حساب", "مبلغ", "کارمزد", "شماره سند",
                                           "یادداشت بانک", "توضیحات"], data)


@bp.route("/payments/form", methods=["GET", "POST"])
def payment_form():
    p = db.session.get(Payment, request.values.get("id", type=int) or 0)
    if request.method == "POST":
        dt, amount = date_or_flash(request.form.get("date")), parse_money(request.form.get("amount"))
        driver_id = request.form.get("driver_id", type=int)
        if not (dt and amount and amount > 0 and driver_id):
            flash("تاریخ، مبلغ و راننده را درست وارد کنید.", "err")
            return render_template("payment_form.html", p=p, form=request.form)
        if not p:
            p = Payment(gross=amount, fee=0)
            db.session.add(p)
        p.date_j, p.date_key, p.amount, p.driver_id = dt[0], dt[1], amount, driver_id
        p.truck_id = request.form.get("truck_id", type=int) or None
        if not p.doc_number:  # دستی
            p.account_number = fix(request.form.get("account_number")).lstrip("0")
            p.gross = amount + (p.fee or 0)
        p.notes = request.form.get("notes", "").strip()
        db.session.commit()
        flash("واریزی ذخیره شد.", "ok")
        return back("main.payments")
    return render_template("payment_form.html", p=p, form=None)


@bp.route("/payments/<int:id>/note", methods=["POST"])
def payment_note(id):
    p = db.get_or_404(Payment, id)
    p.notes = request.form.get("notes", "").strip()
    if "truck_id" in request.form:
        p.truck_id = request.form.get("truck_id", type=int) or None
    db.session.commit()
    return back("main.payments")


@bp.route("/payments/<int:id>/delete", methods=["POST"])
def payment_delete(id):
    db.session.delete(db.get_or_404(Payment, id))
    db.session.commit()
    flash("واریزی حذف شد.", "ok")
    return back("main.payments")


# ------------------------------------------------------------------ رسیدها
@bp.route("/receipts")
def receipts():
    f = parse_filters(request.args)
    q = apply_filters(Receipt.query, Receipt, f, with_text=True)
    total = q.with_entities(func.coalesce(func.sum(Receipt.amount), 0)).scalar()
    page = q.order_by(Receipt.date_key.desc(), Receipt.id.desc()).paginate(
        page=request.args.get("page", 1, type=int), per_page=PER_PAGE, error_out=False)
    return render_template("receipts.html", f=f, page=page, total=int(total))


@bp.route("/receipts/form", methods=["GET", "POST"])
def receipt_form():
    r = db.session.get(Receipt, request.values.get("id", type=int) or 0)
    if request.method == "POST":
        dt, amount = date_or_flash(request.form.get("date")), parse_money(request.form.get("amount"))
        driver_id = request.form.get("driver_id", type=int)
        if not (dt and amount and amount > 0 and driver_id):
            flash("تاریخ، مبلغ و راننده را درست وارد کنید.", "err")
            return back("main.receipts")
        if not r:
            r = Receipt()
            db.session.add(r)
        r.date_j, r.date_key, r.amount, r.driver_id = dt[0], dt[1], amount, driver_id
        r.truck_id = request.form.get("truck_id", type=int) or None
        if not r.truck_id:
            d = db.session.get(Driver, driver_id)
            r.truck_id = d.trucks[0].id if len(d.trucks) == 1 else None
        r.receipt_no = fix(request.form.get("receipt_no"))
        r.notes = request.form.get("notes", "").strip()
        db.session.commit()
        flash("رسید ثبت شد.", "ok")
        return back("main.receipts")
    return render_template("receipt_form.html", r=r)


@bp.route("/receipts/<int:id>/note", methods=["POST"])
def receipt_note(id):
    r = db.get_or_404(Receipt, id)
    r.notes = request.form.get("notes", "").strip()
    db.session.commit()
    return back("main.receipts")


@bp.route("/receipts/<int:id>/delete", methods=["POST"])
def receipt_delete(id):
    db.session.delete(db.get_or_404(Receipt, id))
    db.session.commit()
    flash("رسید حذف شد.", "ok")
    return back("main.receipts")


# ------------------------------------------------------------------ ورود فایل
@bp.route("/import", methods=["GET", "POST"])
def import_page():
    result = kind = None
    if request.method == "POST":
        kind = request.form.get("kind")
        file = request.files.get("file")
        if not file or not file.filename:
            flash("فایلی انتخاب نشده.", "err")
        else:
            try:
                if kind == "statement":
                    result = import_statement(file, fee=parse_money(request.form.get("fee")) or 0)
                else:
                    result = import_callbook(file, sheet=fix(request.form.get("sheet")) or None)
            except Exception as e:  # noqa
                db.session.rollback()
                flash(f"خطا در خواندن فایل: {e}", "err")
    batches = ImportBatch.query.filter_by(kind="statement").order_by(ImportBatch.id.desc()).limit(20).all()
    return render_template("import.html", result=result, kind=kind, batches=batches)


@bp.route("/import/<int:id>/undo", methods=["POST"])
def import_undo(id):
    b = db.get_or_404(ImportBatch, id)
    n = Payment.query.filter_by(batch_id=id).delete()
    db.session.delete(b)
    db.session.commit()
    flash(f"{n} واریزی این فایل حذف شد.", "ok")
    return redirect(url_for("main.import_page"))


# ------------------------------------------------------------------ پشتیبان‌گیری
@bp.route("/backup")
def backup():
    from flask import current_app
    import datetime
    uri = current_app.config["SQLALCHEMY_DATABASE_URI"]
    if not uri.startswith("sqlite:///"):
        flash("پشتیبان‌گیری از اینجا فقط برای نسخه‌ی SQLite است؛ برای PostgreSQL از pg_dump استفاده کنید.", "err")
        return redirect(url_for("main.dashboard"))
    db.session.commit()
    src = uri.replace("sqlite:///", "", 1)
    import sqlite3, tempfile, os
    tmp = os.path.join(tempfile.mkdtemp(), "backup.db")
    con, dst = sqlite3.connect(src), sqlite3.connect(tmp)
    con.backup(dst)
    con.close(); dst.close()
    return send_file(tmp, as_attachment=True,
                     download_name=f"ledger-backup-{datetime.date.today().isoformat()}.db")
