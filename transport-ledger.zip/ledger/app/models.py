from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import UniqueConstraint

db = SQLAlchemy()

driver_trucks = db.Table(
    "driver_trucks",
    db.Column("driver_id", db.Integer, db.ForeignKey("drivers.id"), primary_key=True),
    db.Column("truck_id", db.Integer, db.ForeignKey("trucks.id"), primary_key=True),
)


class Driver(db.Model):
    __tablename__ = "drivers"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    name_norm = db.Column(db.String(200), index=True)
    phone = db.Column(db.String(50), default="")
    notes = db.Column(db.Text, default="")  # توضیحات راننده
    opening_balance = db.Column(db.BigInteger, default=0)  # مثبت = بدهکار از قبل
    active = db.Column(db.Boolean, default=True)
    needs_review = db.Column(db.Boolean, default=False)  # ساخته‌شده خودکار از پرینت بانک
    trucks = db.relationship("Truck", secondary=driver_trucks, back_populates="drivers")
    accounts = db.relationship("Account", back_populates="driver")


class Truck(db.Model):
    __tablename__ = "trucks"
    id = db.Column(db.Integer, primary_key=True)
    plate = db.Column(db.String(50), nullable=False)
    plate_norm = db.Column(db.String(50), index=True, unique=True)
    serial = db.Column(db.String(50), default="")
    kind = db.Column(db.String(200), default="")
    year = db.Column(db.String(10), default="")
    status = db.Column(db.String(100), default="")
    notes = db.Column(db.Text, default="")
    drivers = db.relationship("Driver", secondary=driver_trucks, back_populates="trucks")

    @property
    def label(self):
        return f"{self.plate} ({self.serial})" if self.serial else self.plate


class Account(db.Model):
    __tablename__ = "accounts"
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.String(50), unique=True, nullable=False)  # بدون صفر ابتدایی
    holder_name = db.Column(db.String(200), default="")
    driver_id = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=False)
    notes = db.Column(db.Text, default="")  # توضیحات حساب
    driver = db.relationship("Driver", back_populates="accounts")


class ImportBatch(db.Model):
    __tablename__ = "import_batches"
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(300))
    kind = db.Column(db.String(30))
    created_at = db.Column(db.DateTime, default=datetime.now)
    added = db.Column(db.Integer, default=0)
    skipped = db.Column(db.Integer, default=0)


class Payment(db.Model):
    __tablename__ = "payments"
    __table_args__ = (UniqueConstraint("doc_number", "date_key", "gross", "account_number", name="uq_payment_bank"),)
    id = db.Column(db.Integer, primary_key=True)
    date_j = db.Column(db.String(10), nullable=False)
    date_key = db.Column(db.Integer, nullable=False, index=True)
    amount = db.Column(db.BigInteger, nullable=False)  # مبلغ خالص (ریال)
    fee = db.Column(db.BigInteger, default=0)  # کارمزد بانکی
    gross = db.Column(db.BigInteger, default=0)  # مبلغ کل برداشت
    driver_id = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=False, index=True)
    truck_id = db.Column(db.Integer, db.ForeignKey("trucks.id"), index=True)
    account_id = db.Column(db.Integer, db.ForeignKey("accounts.id"))
    account_number = db.Column(db.String(50), default="")
    doc_number = db.Column(db.String(50))
    row_no = db.Column(db.String(20))
    bank_memo = db.Column(db.Text, default="")  # «یادداشت» بانک
    bank_desc = db.Column(db.Text, default="")  # «توضیحات» بانک
    notes = db.Column(db.Text, default="")  # توضیحات شما برای این واریزی
    batch_id = db.Column(db.Integer, db.ForeignKey("import_batches.id"))
    created_at = db.Column(db.DateTime, default=datetime.now)
    driver = db.relationship("Driver")
    truck = db.relationship("Truck")
    account = db.relationship("Account")


class Receipt(db.Model):
    __tablename__ = "receipts"
    id = db.Column(db.Integer, primary_key=True)
    date_j = db.Column(db.String(10), nullable=False)
    date_key = db.Column(db.Integer, nullable=False, index=True)
    amount = db.Column(db.BigInteger, nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=False, index=True)
    truck_id = db.Column(db.Integer, db.ForeignKey("trucks.id"), index=True)
    receipt_no = db.Column(db.String(100), default="")
    notes = db.Column(db.Text, default="")  # توضیحات رسید
    created_at = db.Column(db.DateTime, default=datetime.now)
    driver = db.relationship("Driver")
    truck = db.relationship("Truck")
