"""اجرای محلی بدون Docker (با SQLite):  python run.py"""
from app import create_app

app = create_app()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=False)
